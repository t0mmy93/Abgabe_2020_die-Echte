namespace terminator {
    
    export class Moving extends Everything {
        speed: number;

        move(): void {};
        draw(): void {};
    }
}