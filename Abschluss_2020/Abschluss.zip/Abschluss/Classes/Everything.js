var terminator;
(function (terminator) {
    class Everything {
        move() { }
        ;
        draw() { }
        ;
    }
    terminator.Everything = Everything;
})(terminator || (terminator = {}));
//# sourceMappingURL=Everything.js.map