var terminator;
(function (terminator) {
    class Moving extends terminator.Everything {
        move() { }
        ;
        draw() { }
        ;
    }
    terminator.Moving = Moving;
})(terminator || (terminator = {}));
//# sourceMappingURL=Moving.js.map