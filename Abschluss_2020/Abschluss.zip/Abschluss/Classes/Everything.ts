namespace terminator {
    export class Everything {
        x: number;
        y: number;
        
        move(): void {};
        draw(): void {};
    }
}